:HL["/_next/static/chunks/5366b7d06a473aad.css","style"]
0:{"buildId":"LhiXIVJgqpsBstYSNLOD_","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
