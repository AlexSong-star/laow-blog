globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5bcee453cc4bce6d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/396f90e8b7ccb31f.js",
    "static/chunks/d702a24e2b6c48fa.js",
    "static/chunks/turbopack-338a85ccd4ffb1eb.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];